/**
 * 
 */
package com.qhit.lh.gr3.xhq.exam.common.dao;

import com.qhit.lh.gr3.xhq.exam.common.bean.User;

/**
 * @author admin
 * 2017年12月27日
 */
public interface UserDao {
	/**
	 * @return
	 */
	public User login(User user); 
}
