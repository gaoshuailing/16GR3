/**
 * 
 */
package com.qhit.lh.gr3.xhq.exam.common.utils;

/**
 * @author admin
 * 2017年12月27日
 * 公共常量类
 */
public class Constants {
	
}
